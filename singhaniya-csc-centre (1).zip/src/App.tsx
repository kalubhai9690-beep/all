import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LiveUpdates } from './components/LiveUpdates';
import { Features } from './components/Features';
import { Services } from './components/Services';
import { Trust } from './components/Trust';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { FloatingElements } from './components/FloatingElements';
import { WelcomePopup } from './components/WelcomePopup';

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <LiveUpdates />
      <Features />
      <Services />
      <Trust />
      <About />
      <Contact />
      <Footer />
      <FloatingElements />
      <WelcomePopup />
    </div>
  );
}
