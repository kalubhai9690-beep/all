import { QrCode, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-navy pt-20 pb-10 border-t border-cyan/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-gradient-to-tr from-cyan to-blue-600 rounded-lg flex items-center justify-center font-bold text-lg text-white">S</div>
              <h1 className="text-xl font-bold tracking-tight text-white">
                Singhaniya <span className="text-cyan">CSC</span>
              </h1>
            </div>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              Your trusted Common Service Centre in Zakhira, Delhi. We provide fast, secure, and reliable digital and government services.
            </p>
            <div className="flex gap-4 cursor-pointer">
              {/* Fake social placeholders */}
              <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-cyan hover:text-navy hover:border-cyan transition-colors">
                ƒ
              </div>
              <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-cyan hover:text-navy hover:border-cyan transition-colors">
                𝕏
              </div>
              <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-cyan hover:text-navy hover:border-cyan transition-colors">
                in
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-400 hover:text-cyan transition-colors text-sm">Home</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-cyan transition-colors text-sm">Services</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-cyan transition-colors text-sm">About Us</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-cyan transition-colors text-sm">Contact</a></li>
              <li><a href="#" className="text-gray-400 hover:text-cyan transition-colors text-sm">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Contact Info</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-cyan flex-shrink-0 mt-0.5" />
                <span className="text-gray-400 text-sm">Rakhi Market, Zakhira, Ramdev Mandir ke Pass, Delhi - 110015</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-cyan flex-shrink-0" />
                <span className="text-gray-400 text-sm">+91 7217653364</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-cyan flex-shrink-0" />
                <span className="text-gray-400 text-sm">info@singhaniyacsc.in</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Pay Securely</h4>
            <div className="bg-white/5 p-4 rounded-xl border border-white/10 text-center">
              <div className="w-24 h-24 mx-auto bg-white p-2 rounded-lg mb-3 flex items-center justify-center">
                <QrCode className="w-20 h-20 text-navy" />
              </div>
              <p className="text-xs text-gray-400">Scan to Pay via UPI</p>
              <div className="flex justify-center gap-2 mt-3">
                <div className="text-[10px] bg-white/10 px-2 py-1 rounded text-gray-300">GPay</div>
                <div className="text-[10px] bg-white/10 px-2 py-1 rounded text-gray-300">PhonePe</div>
                <div className="text-[10px] bg-white/10 px-2 py-1 rounded text-gray-300">Paytm</div>
              </div>
            </div>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Singhaniya CSC Centre. All Rights Reserved.
          </p>
          <p className="text-gray-500 text-sm">
            Designed for Digital India
          </p>
        </div>
      </div>
    </footer>
  );
}
