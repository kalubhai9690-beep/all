import { motion } from "motion/react";
import { Zap } from "lucide-react";

const updates = [
  "Aadhaar Update Service Available",
  "PAN Card Correction Started",
  "Insurance Services Active",
  "Bill Payment Services Running",
  "Mobile Recharge Available",
  "New Government Services Added"
];

export function LiveUpdates() {
  return (
    <div className="bg-black/30 h-[30px] border-y border-white/10 flex items-center overflow-hidden relative text-[12px] uppercase tracking-[1px] text-cyan">
      <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-navy to-transparent z-10 pointer-events-none"></div>
      <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-navy to-transparent z-10 pointer-events-none"></div>
      
      <div className="flex whitespace-nowrap min-w-full">
        <motion.div
          animate={{ x: ["0%", "-50%"] }}
          transition={{ repeat: Infinity, ease: "linear", duration: 25 }}
          className="flex whitespace-nowrap"
        >
          {/* Double the updates array to create a seamless loop */}
          {[...updates, ...updates].map((update, idx) => (
            <div key={idx} className="flex items-center gap-2 mx-8 font-medium">
              <span>⚡</span>
              <span>{update}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
