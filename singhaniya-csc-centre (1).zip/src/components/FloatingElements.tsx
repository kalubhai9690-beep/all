import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, ArrowUp } from 'lucide-react';
import { getWhatsAppLink } from '../lib/utils';

export function FloatingElements() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
      
      <AnimatePresence>
        {showTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: 20 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="w-12 h-12 bg-navy text-white rounded-full shadow-lg flex items-center justify-center hover:bg-navy/90 transition-colors border border-white/10"
          >
            <ArrowUp className="w-5 h-5" />
          </motion.button>
        )}
      </AnimatePresence>

      <motion.a
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: "spring" }}
        href={getWhatsAppLink("Hello! I need some assistance.")}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 bg-green-500 text-white rounded-full shadow-[0_0_20px_rgba(34,197,94,0.4)] flex items-center justify-center hover:scale-110 transition-transform relative group"
      >
        <span className="absolute -inset-2 rounded-full border-2 border-green-500 animate-ping opacity-20"></span>
        <Phone className="w-6 h-6 fill-current" />
        
        {/* Tooltip */}
        <span className="absolute right-full mr-4 bg-navy text-white text-xs font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Chat with us
          <span className="absolute top-1/2 -mt-1 -right-1 border-t-4 border-b-4 border-l-4 border-t-transparent border-b-transparent border-l-navy"></span>
        </span>
      </motion.a>

    </div>
  );
}
