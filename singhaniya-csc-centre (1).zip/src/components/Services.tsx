import { motion } from 'motion/react';
import { ArrowRight, FileText, CreditCard, HeartPulse, ShieldCheck, FileBadge, Plane, GraduationCap, Calculator } from 'lucide-react';
import { getWhatsAppLink } from '../lib/utils';

const servicesList = [
  {
    title: "Aadhaar Services",
    icon: ShieldCheck,
    desc: "Aadhaar Card Download, Print, Address Update, Mobile Number Link, Correction",
    gradient: "from-blue-600 to-cyan-500",
    shadow: "hover:shadow-blue-500/30"
  },
  {
    title: "PAN Card",
    icon: FileBadge,
    desc: "New PAN Card Apply, Instant e-PAN, Corrections, PAN-Aadhaar Link",
    gradient: "from-orange-500 to-amber-500",
    shadow: "hover:shadow-orange-500/30"
  },
  {
    title: "Certificates",
    icon: FileText,
    desc: "Income, Caste, Domicile, Birth & Death Certificate Applications",
    gradient: "from-emerald-500 to-teal-400",
    shadow: "hover:shadow-emerald-500/30"
  },
  {
    title: "Banking & AEPS",
    icon: CreditCard,
    desc: "Cash Withdrawal, Money Transfer, Mini Statement, Account Opening",
    gradient: "from-purple-600 to-indigo-500",
    shadow: "hover:shadow-purple-500/30"
  },
  {
    title: "Insurance",
    icon: HeartPulse,
    desc: "Life, Health, and Vehicle Insurance Plans & Premium Payment",
    gradient: "from-rose-500 to-pink-500",
    shadow: "hover:shadow-rose-500/30"
  },
  {
    title: "Travel Tickets",
    icon: Plane,
    desc: "Railway (IRCTC) Booking, Flight Tickets, Bus Tickets",
    gradient: "from-sky-500 to-blue-400",
    shadow: "hover:shadow-sky-500/30"
  },
  {
    title: "Scholarship & Forms",
    icon: GraduationCap,
    desc: "Student Scholarship Forms, Online Job Applications, College Admission Forms",
    gradient: "from-indigo-500 to-blue-500",
    shadow: "hover:shadow-indigo-500/30"
  },
  {
    title: "Bill Payments",
    icon: Calculator,
    desc: "Electricity Bill, Water Bill, Mobile Recharge, DTH Recharge",
    gradient: "from-teal-500 to-emerald-400",
    shadow: "hover:shadow-teal-500/30"
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">
              Our Premium <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan to-blue-500">Services</span>
            </h2>
            <p className="text-gray-400 text-lg">
              Comprehensive digital and government services delivered with speed, accuracy, and utmost security.
            </p>
          </div>
          
          <div>
            <a 
              href={getWhatsAppLink("Hi, I want to see the full list of services available at Singhaniya CSC.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 btn-premium text-white rounded-lg font-bold"
            >
              View Full Menu <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {servicesList.map((service, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              whileHover={{ y: -5 }}
              className={`glass-panel overflow-hidden transition-all duration-300 group flex flex-col`}
            >
              <div className={`h-1 w-full bg-gradient-to-r ${service.gradient}`}></div>
              <div className="p-6 flex-1 flex flex-col hover:bg-white/5 transition-colors">
                <div className={`w-12 h-12 rounded-xl mb-4 flex items-center justify-center bg-gradient-to-br ${service.gradient} text-white shadow-md`}>
                  <service.icon className="w-6 h-6" />
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
                <p className="text-gray-400 text-sm mb-6 flex-1 leading-relaxed">
                  {service.desc}
                </p>
                
                <a 
                  href={getWhatsAppLink(`Hi, I would like to apply for or inquire about ${service.title} services.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-cyan hover:text-navy text-white font-semibold rounded-lg transition-all border border-white/10 mt-auto"
                >
                  Apply Now <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
