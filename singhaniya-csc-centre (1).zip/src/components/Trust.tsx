import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Star, ShieldCheck, Users, Award, Clock } from 'lucide-react';

export function Trust() {
  const [stats, setStats] = useState({
    customers: 0,
    services: 0,
    years: 0
  });

  useEffect(() => {
    // Simple counter animation
    const duration = 2000; // 2 seconds
    const interval = 20;
    const steps = duration / interval;
    
    let currentStep = 0;
    
    const timer = setInterval(() => {
      currentStep++;
      if (currentStep === steps) {
        clearInterval(timer);
        setStats({ customers: 15000, services: 50, years: 5 });
      } else {
        setStats({
          customers: Math.floor((15000 / steps) * currentStep),
          services: Math.floor((50 / steps) * currentStep),
          years: Math.floor((5 / steps) * currentStep),
        });
      }
    }, interval);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 leading-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center md:text-left mb-16 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-xl">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-extrabold text-white mb-4"
            >
              Trusted by Thousands in <span className="text-cyan">Delhi</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-gray-400"
            >
              We've built our reputation on trust, security, and lightning-fast service delivery.
            </motion.p>
          </div>
          
          <div className="flex gap-4">
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg border border-white/10">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span className="text-white font-medium">100% Secure</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg border border-white/10">
              <Award className="w-5 h-5 text-cyan" />
              <span className="text-white font-medium">Govt. Verified</span>
            </div>
          </div>
        </div>

        {/* Counters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mb-20">
          {[
            { icon: Users, count: `${stats.customers.toLocaleString()}+`, label: "Happy Customers", color: "text-blue-400" },
            { icon: ShieldCheck, count: "99.9%", label: "Success Rate", color: "text-emerald-400" },
            { icon: Clock, count: `${stats.years}+`, label: "Years Experience", color: "text-purple-400" },
            { icon: Star, count: "4.9/5", label: "Average Rating", color: "text-amber-400" }
          ].map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass-panel p-6 text-center flex flex-col items-center justify-center transform hover:-translate-y-1 transition-transform"
            >
              <stat.icon className={`w-8 h-8 ${stat.color} mb-3`} />
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-1">{stat.count}</h3>
              <p className="text-gray-400 text-sm font-medium uppercase tracking-wider">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Reviews */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { name: "Rahul Verma", text: "Got my PAN card corrected within days. Very professional service and they kept me updated on WhatsApp.", date: "2 days ago" },
            { name: "Priya Sharma", text: "Best CSC center in Zakhira. The staff is very helpful and the Aadhaar update process was super fast.", date: "1 week ago" },
            { name: "Amit Kumar", text: "Applied for income certificate. Very smooth process, didn't have to wait in long queues. Highly recommended!", date: "2 weeks ago" }
          ].map((review, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass-panel p-6"
            >
              <div className="flex text-amber-400 mb-4">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="text-gray-300 mb-6 italic leading-relaxed">"{review.text}"</p>
              <div className="flex items-center gap-3 mt-auto">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan to-blue-600 flex items-center justify-center text-white font-bold text-sm">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{review.name}</h4>
                  <p className="text-xs text-cyan">Google Review • {review.date}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
