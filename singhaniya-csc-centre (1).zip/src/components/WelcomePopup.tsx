import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, X, ArrowRight } from 'lucide-react';
import { getWhatsAppLink } from '../lib/utils';

export function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsOpen(true);
    }, 3000); // Popup after 3 seconds
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-navy/80 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="glass-panel rounded-3xl p-6 sm:p-8 max-w-md w-full relative overflow-hidden"
          >
            {/* Top decorative gradient */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400"></div>
            
            <button 
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors bg-white/5 rounded-full p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center mb-6 mx-auto shadow-inner text-cyan">
              <Bell className="w-8 h-8" />
            </div>

            <div className="text-center">
              <h3 className="text-2xl font-bold text-white mb-2">Notice Updates!</h3>
              <p className="text-gray-400 mb-6 text-sm leading-relaxed">
                PAN card and Aadhaar linked services are currently processing very fast. Apply today to avoid penalties!
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <a
                href={getWhatsAppLink("I have a query regarding Aadhaar/PAN linking.")}
                target="_blank"
                rel="noopener noreferrer" 
                onClick={() => setIsOpen(false)}
                className="w-full py-3.5 btn-premium rounded-xl flex items-center justify-center gap-2"
              >
                Inquire Now <ArrowRight className="w-4 h-4" />
              </a>
              <button 
                onClick={() => setIsOpen(false)}
                className="w-full py-3.5 text-gray-400 hover:text-white font-medium rounded-xl hover:bg-white/5 transition-colors"
              >
                Maybe Later
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
