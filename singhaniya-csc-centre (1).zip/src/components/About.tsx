import { motion } from 'motion/react';
import { CheckCircle2, Shield, Computer, FileCheck } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-block px-4 py-2 rounded-full bg-cyan/10 border border-cyan/20 text-cyan font-semibold mb-6 text-xs uppercase tracking-widest flex items-center gap-2 w-max">
              <Shield className="w-4 h-4" /> About Singhaniya CSC
            </div>
            <h2 className="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-6">
              Your Trusted Partner for <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan to-blue-500">Government Services</span>
            </h2>
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              Located in the heart of Delhi at Rakhi Market, Zakhira, Singhaniya CSC Centre simplifies your digital life. We bridge the gap between citizens and critical government services with a focus on speed, accuracy, and absolute security. 
            </p>
            
            <div className="space-y-4 mb-8">
              {[
                "Government Authorized Service Center",
                "Expert & Trained Professionals",
                "100% Data Security & Privacy",
                "No Hidden Charges"
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-cyan flex-shrink-0" />
                  <span className="text-gray-200 font-medium">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan/20 blur-[80px] rounded-full pointer-events-none"></div>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="glass-panel p-6 z-10 sm:translate-y-8"
            >
              <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center mb-4">
                <FileCheck className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Secure Docs</h3>
              <p className="text-gray-400 text-sm">Strict document handling protocols to ensure your PII data is never compromised.</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="glass-panel p-6 z-10"
            >
              <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center mb-4">
                <Computer className="w-6 h-6 text-cyan" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Digital Solutions</h3>
              <p className="text-gray-400 text-sm">Advanced digital systems for fast processing of forms, tickets, and banking needs.</p>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
