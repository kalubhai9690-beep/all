import { motion } from 'motion/react';
import { FastForward, Shield, Headphones, Smartphone } from 'lucide-react';

const features = [
  {
    icon: FastForward,
    title: "Fast Processing",
    desc: "Lightning fast processing of all your applications with real-time updates.",
    color: "from-blue-500 to-cyan-400"
  },
  {
    icon: Shield,
    title: "Secure Services",
    desc: "100% secure and verified process. Your data and privacy is our top priority.",
    color: "from-emerald-500 to-teal-400"
  },
  {
    icon: Headphones,
    title: "Professional Support",
    desc: "Expert guidance available. Dedicated WhatsApp support for all queries.",
    color: "from-purple-500 to-pink-400"
  },
  {
    icon: Smartphone,
    title: "Mobile Friendly",
    desc: "Access tracking and service information directly on your mobile device.",
    color: "from-orange-500 to-yellow-400"
  }
];

export function Features() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[400px] bg-cyan/5 rounded-[100%] blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-extrabold text-white mb-4"
          >
            Why Choose Singhaniya CSC?
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="w-20 h-1 bg-cyan mx-auto rounded-full mb-6"
          ></motion.div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-gray-400 text-lg"
          >
            We provide a premium digital service experience backed by maximum security, speed, and support.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ y: -10 }}
              className="glass-panel p-8 hover:border-cyan/50 transition-all duration-300 group relative overflow-hidden"
            >
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 bg-gradient-to-br ${feature.color} shadow-lg text-white transform group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-7 h-7" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed text-sm">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
