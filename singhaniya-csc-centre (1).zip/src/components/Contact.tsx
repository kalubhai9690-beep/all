import { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Send, Upload, ChevronDown } from 'lucide-react';
import { getWhatsAppLink } from '../lib/utils';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    service: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = `Hi, my name is ${formData.name}.\nI am looking for: ${formData.service}\nMessage: ${formData.message}`;
    window.open(getWhatsAppLink(text), '_blank');
  };

  return (
    <section id="contact" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4">
            Visit Us or <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan to-blue-500">Get in Touch</span>
          </h2>
          <p className="text-gray-400 text-lg">
            We are here to assist you. Send us a message on WhatsApp or visit our centre directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column: Form & Details */}
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              <div className="glass-panel p-6 flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-cyan/10 rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-cyan" />
                </div>
                <h3 className="font-bold text-white mb-2">Our Location</h3>
                <p className="text-sm text-gray-400">Rakhi Market, Zakhira, Ramdev Mandir ke Pass, Delhi - 110015</p>
              </div>
              <div className="glass-panel p-6 flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mb-4">
                  <Phone className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="font-bold text-white mb-2">WhatsApp Support</h3>
                <p className="text-sm text-gray-400">+91 7217653364</p>
                <a href={getWhatsAppLink("Hello")} target="_blank" rel="noopener noreferrer" className="text-xs font-bold text-green-500 mt-2 hover:underline">Message Now</a>
              </div>
            </div>

            <div className="glass-panel p-8">
              <h3 className="text-2xl font-bold text-white mb-6">Send an Inquiry</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Your Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-cyan focus:border-transparent outline-none transition-all placeholder:text-gray-500" 
                    placeholder="Enter your name" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Select Service</label>
                  <div className="relative">
                    <select 
                      required
                      value={formData.service}
                      onChange={(e) => setFormData({...formData, service: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-cyan focus:border-transparent outline-none transition-all appearance-none"
                    >
                      <option value="" disabled className="bg-navy">Choose a service</option>
                      <option value="Aadhaar Services" className="bg-navy text-white">Aadhaar Services</option>
                      <option value="PAN Card" className="bg-navy text-white">PAN Card</option>
                      <option value="Certificates" className="bg-navy text-white">Certificates (Income/Caste)</option>
                      <option value="Banking" className="bg-navy text-white">Banking & AEPS</option>
                      <option value="Insurance" className="bg-navy text-white">Insurance</option>
                      <option value="Ticket Booking" className="bg-navy text-white">Ticket Booking</option>
                      <option value="Other" className="bg-navy text-white">Other</option>
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Message Detail</label>
                  <textarea 
                    required
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-cyan focus:border-transparent outline-none transition-all resize-none placeholder:text-gray-500" 
                    placeholder="Briefly describe what you need..." 
                  ></textarea>
                </div>
                
                <p className="text-xs text-gray-400 flex items-center gap-1 mb-4">
                  <Upload className="w-3 h-3" /> Note: You can upload files directly in WhatsApp when redirected.
                </p>

                <button 
                  type="submit" 
                  className="w-full flex items-center justify-center gap-2 btn-premium py-4 rounded-xl font-bold"
                >
                  <Send className="w-4 h-4" /> Send to WhatsApp
                </button>
              </form>
            </div>
          </div>

          {/* Right Column: Google Maps */}
          <div className="relative h-full min-h-[400px] glass-panel p-2 group">
            <div className="absolute top-6 left-6 right-6 glass-dark p-4 rounded-xl flex items-start gap-4 z-10 transition-transform transform group-hover:-translate-y-24 duration-300">
              <Clock className="w-6 h-6 text-cyan flex-shrink-0" />
              <div>
                <h4 className="font-bold text-white text-sm">Business Hours</h4>
                <p className="text-xs text-gray-300 font-medium">Mon - Sat: 9:00 AM - 8:00 PM</p>
                <p className="text-xs text-rose-400 font-medium">Sunday: Closed</p>
              </div>
            </div>
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1m3!1m2!1s0x390d0353c7a6a4df%3A0x86bdced08b29df92!2sRakhi%20Market%2C%20Zakhira%2C%20New%20Delhi%2C%20Delhi%20110015!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
              className="absolute inset-[8px] w-[calc(100%-16px)] h-[calc(100%-16px)] border-0 rounded-xl filter grayscale contrast-125 opacity-80"
              allowFullScreen={false} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
}
