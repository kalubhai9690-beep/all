import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ChevronDown, Phone, ShieldCheck, FileText, CreditCard, HeartPulse } from 'lucide-react';
import { getWhatsAppLink } from '../lib/utils';

const services = [
  {
    category: "Government Services",
    icon: <ShieldCheck className="w-5 h-5 text-royal" />,
    items: ["Aadhaar Services", "PAN Card", "Passport Services", "Birth Certificate", "Death Certificate", "Income Certificate", "Caste Certificate", "Domicile Certificate"]
  },
  {
    category: "Digital Services",
    icon: <FileText className="w-5 h-5 text-royal" />,
    items: ["Bill Payments", "Mobile Recharge", "Online Form Filling", "Scholarship Forms", "Railway Ticket Booking", "Flight Ticket Booking", "Job Applications"]
  },
  {
    category: "Banking Services",
    icon: <CreditCard className="w-5 h-5 text-royal" />,
    items: ["AEPS", "Money Transfer", "Cash Withdrawal", "Mini Statement", "Account Opening", "KYC Update"]
  },
  {
    category: "Insurance Services",
    icon: <HeartPulse className="w-5 h-5 text-royal" />,
    items: ["Health Insurance", "Vehicle Insurance", "Life Insurance"]
  }
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass-panel rounded-none border-b border-white/10' : 'bg-transparent'} py-3`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[50px]">
          
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo(0,0)}>
            <div className="w-10 h-10 bg-gradient-to-tr from-cyan to-blue-600 rounded-lg flex items-center justify-center font-bold text-xl text-white">S</div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Singhaniya <span className="text-cyan">CSC</span>
            </h1>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#home" className={`text-sm font-medium hover:text-cyan transition-colors text-white/90`}>Home</a>
            
            {/* Services Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('services')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className={`flex items-center gap-1 text-sm font-medium hover:text-cyan transition-colors text-white/90`}>
                Services <ChevronDown className="w-4 h-4" />
              </button>
              
              <AnimatePresence>
                {activeDropdown === 'services' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full left-1/2 -translate-x-1/2 mt-4 w-[600px] glass-panel p-6 grid grid-cols-2 gap-6"
                  >
                    {/* Invisible bridge to keep hover state */}
                    <div className="absolute -top-4 left-0 right-0 h-4"></div>
                    
                    {services.map((section, idx) => (
                      <div key={idx} className="space-y-3">
                        <h3 className="flex items-center gap-2 font-semibold text-white border-b border-white/10 pb-2">
                          {section.icon} {section.category}
                        </h3>
                        <ul className="space-y-2">
                          {section.items.map((item, i) => (
                            <li key={i}>
                              <a 
                                href={getWhatsAppLink(`Hi, I need help with ${item}.`)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm text-gray-400 hover:text-cyan hover:pl-2 transition-all flex items-center before:content-[''] before:w-1 before:h-1 before:bg-cyan before:rounded-full before:mr-2 before:opacity-0 hover:before:opacity-100"
                              >
                                {item}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <a href="#about" className={`text-sm font-medium hover:text-cyan transition-colors text-white/90`}>About</a>
            <a href="#contact" className={`text-sm font-medium hover:text-cyan transition-colors text-white/90`}>Contact</a>
            
            <a 
              href={getWhatsAppLink("Hi, I want to inquire about your services.")}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2 bg-cyan/10 border border-cyan/50 text-cyan rounded-full text-sm font-bold flex items-center gap-2 hover:bg-cyan/20 transition-colors"
            >
              <span>Support</span>
              <div className="w-2 h-2 bg-cyan rounded-full animate-pulse"></div>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-dark absolute top-full left-0 right-0 border-t border-white/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              <a onClick={() => setMobileMenuOpen(false)} href="#home" className="block px-3 py-3 text-base text-white/90 hover:text-cyan border-b border-white/5">Home</a>
              <div className="px-3 py-3 text-base text-white/90 border-b border-white/5">
                <span className="font-semibold text-cyan mb-2 block">Services</span>
                <div className="grid grid-cols-1 gap-4 pl-2 mt-2">
                  {services.map((section, idx) => (
                    <div key={idx}>
                      <div className="text-sm text-gray-400 mb-1">{section.category}</div>
                      <div className="flex flex-wrap gap-2">
                        {section.items.map((item, i) => (
                          <a 
                            key={i}
                            href={getWhatsAppLink(`Hi, I need help with ${item}.`)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs bg-white/5 px-2 py-1 rounded text-white/80 hover:bg-white/10"
                          >
                            {item}
                          </a>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <a onClick={() => setMobileMenuOpen(false)} href="#about" className="block px-3 py-3 text-base text-white/90 hover:text-cyan border-b border-white/5">About</a>
              <a onClick={() => setMobileMenuOpen(false)} href="#contact" className="block px-3 py-3 text-base text-white/90 hover:text-cyan border-b border-white/5">Contact</a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
